from __future__ import absolute_import, division, print_function
import pkg_resources
from aws_bucket_creator.BucketCreator import BucketCreator #noqa

__version__ = pkg_resources.get_distribution('aws_bucket_creator').version

__all__ = [
]
__title__ = 'aws_bucket_creator'
__version__ = '0.0.3'
__author__ = 'Will Rubel'
__author_email__ = 'willrubel@gmail.com'

